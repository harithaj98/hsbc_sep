import { Component,OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { AngularDemoService } from './insta-service.service';
import { AngularDemoEntity } from './angularDemoEntity';


@Component({
  selector: 'angularDemo',
  templateUrl: './angular-demo.component.html'
})

// tslint:disable-next-line: class-name
export class angularDemoComponent implements OnInit {
  user: AngularDemoEntity[];//POJO OBJECT
  newTodo: AngularDemoEntity = new AngularDemoEntity();
  newUser: AngularDemoEntity = new AngularDemoEntity();
  editing: boolean = false;
  editingUser: AngularDemoEntity = new AngularDemoEntity();
  editingIndex:number=-1;
    

	constructor(
	  private instaService: AngularDemoService,//DEPENDENCY INJECTION
	) {}

	ngOnInit(): void {
		this.getUser();
  }

  getUser(): void {
    this.instaService.getUser()
      .then(users => this.user = users);
  }

  createUser(instaForm: NgForm): void {
    this.instaService.createUser(this.newUser)
      .then(createUser => {
      //  instaForm.reset();
        this.user.unshift(this.newUser);
	      this.newUser = new AngularDemoEntity();

      });
  }

  
  deleteUser(email: string): void {
    console.log(email);
  	 this.instaService.deleteUser(email)
  	.then(() => {
  		this.user = this.user.filter(users => users.email !== email);
    });

}


editUser(user:  AngularDemoEntity, i :number ): void {
  // this.editing = true;
   this.editingIndex = i;
   Object.assign(this.editingUser, user);
 }


 updateUser(user: AngularDemoEntity): void {
  this.instaService.updateUser(user)
  .then(() => {
    Object.assign(this.user[this.editingIndex],this.editingUser)
    this.clearEditing();
  });
}

clearEditing(): void {
  this.editingUser = new AngularDemoEntity();
  this.editingIndex=-1;
}




}
