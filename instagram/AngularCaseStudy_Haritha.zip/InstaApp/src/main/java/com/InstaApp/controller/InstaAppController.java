package com.InstaApp.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.InstaApp.Dao.DaoInterface;
import com.InstaApp.model.InstaUser;
import com.InstaApp.repo.ConnManager;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class InstaAppController {
	

	@Autowired
	private DaoInterface ti;
	
	@GetMapping("GetEmployee")
	public List<InstaUser> view()
	{
		
		
		List<InstaUser>ll;
	     ll= ti.createprofile();
	     
	     return ll;
		
	}
	   @PostMapping("GetEmployee")
	    public  void createTodo(@Validated @RequestBody InstaUser emp) throws Exception {
		   
		   ti.insertprofile(emp);
	       
	    }
	   
	   
	   @DeleteMapping(value="/GetEmployee/{email}")
	    public  void deleteEmp(@Validated @PathVariable String email) throws Exception {
		   
		   InstaUser fu=new InstaUser();
		   fu.setEmail(email);
		   ti.deleteEmployee(fu);
	       
	    }
	   
	   @PutMapping(value="/GetEmployee/{email}")
	    public void editEmp(@Validated @PathVariable String email,@RequestBody InstaUser emp) throws Exception {
		   
		   ti.editEmployee(emp,email);
	       
	    }

	
	
	
	
	
	
	
	
}
