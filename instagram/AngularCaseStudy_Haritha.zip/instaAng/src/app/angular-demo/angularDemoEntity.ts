export class AngularDemoEntity {
    name: string;
    password: string;
    email: string;
    address: string;
  }
  