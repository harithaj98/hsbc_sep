package com.InstaApp.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnManager {

		private final static String DRIVER_NAME = "org.apache.derby.jdbc.EmbeddedDriver";
		private final static String CONNECTION_STRING_WINDOWS = "jdbc:derby:c:/db/InstaApp;create=true";
		private final static String DB_USERNAME = "haritha";
		private final static String DB_PASSWORD = "hari";
		
		private static Connection con;
		
		private ConnManager () {}
		
		
		/**
		 * @return Connection
		 * @throws Exception
		 */
		public static Connection getConnection () throws SQLException, ClassNotFoundException {
			
			try {
				
				Class.forName(DRIVER_NAME);
					con = DriverManager.getConnection(CONNECTION_STRING_WINDOWS, DB_USERNAME, DB_PASSWORD);
				
				return con;
			}
			catch (SQLException | ClassNotFoundException e) {
				
				// TODO log error to error.log
				throw e;
			}
		}
		
		/**
		 * @throws SQLException
		 */
		public static void close () {
			
			try {
				con.close();
			}
			catch (SQLException e) {
				
				// TODO log error to error.log
				e.printStackTrace();
				// throw e;
			}
		}
	
}
