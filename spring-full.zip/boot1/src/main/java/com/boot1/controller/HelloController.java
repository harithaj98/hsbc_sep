package com.boot1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot1.entity.Employee;

@RestController
public class HelloController {
	
	@RequestMapping("listEmployee")
	public List<Employee> ll(){
		
		List<Employee> ee= new ArrayList<Employee>();
		
		Employee e1= new Employee();
		e1.setName("Hari");
		e1.setPassword("123");
		e1.setEmail("abc@yahoo.com");
		e1.setAddress("Kerala");
		
		
		Employee e2= new Employee();
		e2.setName("Rajesh");
		e2.setPassword("456");
		e2.setEmail("def@yahoo.com");
		e2.setAddress("UP");
		ee.add(e1);
		ee.add(e2);
		return ee;
			
	}
	
	@PostMapping("listEmployee")
	public String ll1() {
		
		return("created");
	}
	
	@PutMapping("listEmployee")
	public String ll2() {
		
		return("edited");
	}
	
	@DeleteMapping("listEmployee")
	public String ll3() {
		
		return("deleted");
	}
	
	


}
