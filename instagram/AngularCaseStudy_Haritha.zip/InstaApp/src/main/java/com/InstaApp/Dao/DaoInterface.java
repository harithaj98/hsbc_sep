package com.InstaApp.Dao;

import java.util.List;

import com.InstaApp.model.InstaUser;


public interface DaoInterface {
	
	public List<InstaUser> createprofile();

	public void insertprofile(InstaUser emp) throws Exception;

	public void deleteEmployee(InstaUser fu) throws Exception;

	public void editEmployee(InstaUser emp, String email) throws Exception;
}
