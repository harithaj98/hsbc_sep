import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AngularDemoEntity} from './angularDemoEntity';

@Injectable({
  providedIn: 'root'
})

export class AngularDemoService {

  private baseUrl = 'http://localhost:8090';

  constructor(private http: HttpClient) { }

  getUser(): Promise<AngularDemoEntity[]> {
    return this.http.get(this.baseUrl + '/api/GetEmployee/')
      .toPromise()
      .then(response => response as AngularDemoEntity[])
      .catch(this.handleError);
  }
  createUser(user: AngularDemoEntity): Promise<AngularDemoEntity> {
    console.log(user);
    return this.http.post(this.baseUrl + '/api/GetEmployee/', user)
      .toPromise().then(response => response as AngularDemoEntity)
      .catch(this.handleError);
  }
  deleteUser(email: string): Promise<any> {
    return this.http.delete(this.baseUrl + '/api/GetEmployee/' + email)
      .toPromise()
      .catch(this.handleError);
  }

  updateUser(user: AngularDemoEntity): Promise<AngularDemoEntity> {
    return this.http.put(this.baseUrl + '/api/GetEmployee/' + user.email, user)
      .toPromise()
      .then(response => response as AngularDemoEntity)
      .catch(this.handleError);
  }


private handleError(error: any): Promise<any> {
    console.error('Some error occured', error);
    return Promise.reject(error.message || error);
  }

}

