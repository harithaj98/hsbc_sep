package com.InstaApp.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.InstaApp.model.InstaUser;
import com.InstaApp.repo.ConnManager;


@Repository
public class AngularDao implements DaoInterface{

	
	
	@Override
	public List<InstaUser> createprofile() {
		// TODO Auto-generated method stub
	
			
			List<InstaUser> ll=new ArrayList<InstaUser>();
			try
			{
			Connection con=ConnManager.getConnection();
			
			PreparedStatement ps=con.prepareStatement("select * from users ");
			
			
			
			
			System.out.println("hi");
			
			ResultSet res=ps.executeQuery();
			
			
			
			while(res.next()) {
				InstaUser fu=new InstaUser();
				//System.out.println(res.getString(1));
				fu.setName(res.getString(1));
				fu.setPassword(res.getString(2));
				fu.setEmail(res.getString(3));
				fu.setAddress(res.getString(4));
				
				ll.add(fu);

		
			}
			
			
			
			
			}catch(Exception e)
			{
				
			}
			return ll; 
	
	}

	@Override
	public void insertprofile(InstaUser emp) throws Exception{
		
		
		
		
		Connection con=ConnManager.getConnection();
		
		PreparedStatement ps=con.prepareStatement("insert into users values(?,?,?,?)");
		
		ps.setString(1,emp.getName());
		ps.setString(2,emp.getPassword());
		ps.setString(3,emp.getEmail());
		ps.setString(4,emp.getAddress());
		
		ps.executeUpdate();
		

	}

	@Override
	public void deleteEmployee(InstaUser fu) throws Exception {
	
		Connection con=ConnManager.getConnection();
		System.out.println(fu.getEmail());
		PreparedStatement ps=con.prepareStatement("delete from users where email=?");
		
		ps.setString(1, fu.getEmail());
		
		ps.executeUpdate();
		
		
	}

	@Override
	public void editEmployee(InstaUser emp, String email) throws Exception {
		
		
		Connection con=ConnManager.getConnection();
		PreparedStatement ps=con.prepareStatement("update  users set name=?,password=?,address=? where email=?");
		ps.setString(1, emp.getName());
		ps.setString(2, emp.getPassword());
		ps.setString(3, emp.getAddress());
		ps.setString(4, email);
		ps.executeUpdate();
		
		
		
	}

}
