package com.InstaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
