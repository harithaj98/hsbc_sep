import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { angularDemoComponent } from './angular-demo/angular-demo.component';
import { AngularDemoService } from './angular-demo/insta-service.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    angularDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	HttpClientModule,
    FormsModule
  ],
  providers: [AngularDemoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
